Swerve


�2000 by Jesse Burgheimer
Version 1.0

These fonts are FREE. Freeware. No quarter asked, no quarter given.
Please do not redistribute without expressly written consent of the creator (Down10 aka Jesse Burgheimer).


Swerve is a COMPLETELY ORIGINAL typeface which was drawn and developed entirely by myself. Swerve is available in three weights�regular, bold, and light�and includes built-in italics. Each font contains a full character set as well, so you are welcome to use it for other languages beyond English.

Swerve adds to an otherwise overflowing number of technical based fonts, but it differs from the others with its angular shape and its '70s style curves. Swerve is best suited for high-tech and industrial applications, but it's surprisingly flexible, so to speak.

In the future, I'll adjust the font for better spacing, hinting and kerning, so return to my site for updates.


Thanks for the download!

�Jesse D. Burgheimer \ Down10
jesse@down10.com
http://www.down10.com/